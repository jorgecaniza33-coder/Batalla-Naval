# LECCIÓN 13: colocar_flota_aleatoria (la pieza que usa el juego local)
# Cómo ejecutarlo: python prueba_13_flota_aleatoria.py

# --- Esto permite importar game_logic.py desde la carpeta de arriba ---
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
# ----------------------------------------------------------------------

from game_logic import Tablero, BARCO

for intento in range(5):
    t = Tablero()
    t.colocar_flota_aleatoria()

    total = 0
    for fila in t.celdas:
        for casilla in fila:
            if casilla == BARCO:
                total = total + 1

    print("Intento", intento + 1, "-> B en el tablero:", total, "| flota completa:", t.flota_completa())
    # ESPERADO en los 5 intentos: B en el tablero: 17 | flota completa: True
    # (5 + 4 + 3 + 3 + 2 = 17 casillas de barco)

print()
t.__init__()
t.colocar_flota_aleatoria()
for fila in t.celdas:
    print(" ".join(fila))
# ESPERADO: un tablero con los 5 barcos puestos al azar, sin que se toquen entre sí
