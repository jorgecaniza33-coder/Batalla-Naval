# LECCIÓN 5: puede_colocar (¿cabe el barco y la zona está libre?)
# Cómo ejecutarlo: python prueba_05_puede_colocar.py

# --- Esto permite importar game_logic.py desde la carpeta de arriba ---
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
# ----------------------------------------------------------------------

from game_logic import Tablero, BARCO

t = Tablero()
print(t.puede_colocar(3, 9, 2, True))    # ESPERADO: False  (se sale por la derecha)
print(t.puede_colocar(3, 8, 2, True))    # ESPERADO: True   (justo cabe)

# Simulamos un barco ya puesto en la casilla (2, 3)
t.celdas[2][3] = BARCO
print(t.puede_colocar(2, 2, 3, True))    # ESPERADO: False  (el nuevo barco pasaría por (2,3), que está ocupada)
print(t.puede_colocar(5, 2, 3, True))    # ESPERADO: True   (otra zona, libre)
