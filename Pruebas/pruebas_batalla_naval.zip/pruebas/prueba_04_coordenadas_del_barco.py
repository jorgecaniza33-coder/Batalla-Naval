# LECCIÓN 4: _coordenadas (calcula las casillas que ocuparía un barco)
# Cómo ejecutarlo: python prueba_04_coordenadas_del_barco.py

# --- Esto permite importar game_logic.py desde la carpeta de arriba ---
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
# ----------------------------------------------------------------------

from game_logic import Tablero

t = Tablero()

# Argumentos: (fila, col, largo, horizontal)
print(t._coordenadas(2, 2, 3, True))     # ESPERADO: [(2, 2), (2, 3), (2, 4)]   -> hacia la derecha
print(t._coordenadas(2, 2, 3, False))    # ESPERADO: [(2, 2), (3, 2), (4, 2)]   -> hacia abajo

# El Destructor (largo 2) desde la fila 3, columna 9, horizontal:
print(t._coordenadas(3, 9, 2, True))     # ESPERADO: [(3, 9), (3, 10)]  -> la columna 10 no existe, no cabe
