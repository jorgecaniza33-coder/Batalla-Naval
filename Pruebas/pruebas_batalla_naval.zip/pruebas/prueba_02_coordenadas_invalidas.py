# LECCIÓN 2: que parsear_coordenada no se rompa con entradas raras
# Cómo ejecutarlo: python prueba_02_coordenadas_invalidas.py

# --- Esto permite importar game_logic.py desde la carpeta de arriba ---
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
# ----------------------------------------------------------------------

from game_logic import parsear_coordenada

for prueba in ["B5", "b5", " J10 ", "Z99", "hola", "A0", "A11", ""]:
    print(repr(prueba), "->", parsear_coordenada(prueba))

# ESPERADO:
# 'B5' -> (1, 4)
# 'b5' -> (1, 4)
# ' J10 ' -> (9, 9)
# 'Z99' -> None
# 'hola' -> None
# 'A0' -> None       (la columna sería -1)
# 'A11' -> None      (la columna sería 10, se pasa)
# '' -> None         (menos de 2 caracteres)
