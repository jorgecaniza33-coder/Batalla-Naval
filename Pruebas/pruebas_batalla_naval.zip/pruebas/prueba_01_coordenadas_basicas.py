# LECCIÓN 1: dentro_del_tablero y parsear_coordenada
# Cómo ejecutarlo: python prueba_01_coordenadas_basicas.py

# --- Esto permite importar game_logic.py desde la carpeta de arriba ---
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
# ----------------------------------------------------------------------

from game_logic import dentro_del_tablero, parsear_coordenada

print(dentro_del_tablero(3, 5))     # ESPERADO: True
print(dentro_del_tablero(3, 10))    # ESPERADO: False  (la columna 10 no existe, llega hasta 9)

print(parsear_coordenada("B5"))     # ESPERADO: (1, 4)
print(parsear_coordenada("A1"))     # ESPERADO: (0, 0)
print(parsear_coordenada("J10"))    # ESPERADO: (9, 9)
