# LECCIÓN 7: FLOTA, flota_completa y quitar_barco
# Cómo ejecutarlo: python prueba_07_flota_y_quitar.py

# --- Esto permite importar game_logic.py desde la carpeta de arriba ---
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
# ----------------------------------------------------------------------

from game_logic import Tablero, FLOTA

t = Tablero()

# Un barco por fila, todos pegados a la izquierda y en horizontal
fila = 0
for nombre, largo in FLOTA:
    t.colocar_barco(nombre, fila, 0, largo, True)
    fila = fila + 1

print(t.flota_completa())    # ESPERADO: True  (5 barcos)

for f in t.celdas:
    print(" ".join(f))
# ESPERADO: las filas 0 a 4 tienen 5, 4, 3, 3 y 2 letras B

t.quitar_barco("Crucero")
print()
print(t.flota_completa())    # ESPERADO: False  (ahora hay 4 barcos)

for f in t.celdas:
    print(" ".join(f))
# ESPERADO: la fila 2 (la del Crucero) quedó toda en "~"

print()
print(t.quitar_barco("Lancha"))    # ESPERADO: False  (ese barco no existe, y no da error)
