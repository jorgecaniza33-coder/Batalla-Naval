# LECCIÓN 12: Conexion (mensajes JSON por un socket)
# Cómo ejecutarlo: python prueba_12_conexion.py
# Usamos socket.socketpair(): dos sockets ya conectados entre sí, en tu misma computadora.
# OJO: recibir() espera hasta que llegue un mensaje; si nadie envía nada, parece trabado.

# --- Esto permite importar game_logic.py desde la carpeta de arriba ---
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
# ----------------------------------------------------------------------

import socket
from game_logic import Conexion

a, b = socket.socketpair()
jugador1 = Conexion(a)
jugador2 = Conexion(b)

jugador1.enviar({"tipo": "disparo", "fila": 1, "col": 4})
print(jugador2.recibir())    # ESPERADO: {'tipo': 'disparo', 'fila': 1, 'col': 4}

jugador2.enviar({"tipo": "resultado", "resultado": "tocado"})
print(jugador1.recibir())    # ESPERADO: {'tipo': 'resultado', 'resultado': 'tocado'}

jugador1.cerrar()
print(jugador2.recibir())    # ESPERADO: None   (el otro jugador se desconectó)
