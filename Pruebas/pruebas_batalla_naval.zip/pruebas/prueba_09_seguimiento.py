# LECCIÓN 9: Seguimiento (lo que sabemos del tablero del rival)
# Cómo ejecutarlo: python prueba_09_seguimiento.py

# --- Esto permite importar game_logic.py desde la carpeta de arriba ---
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
# ----------------------------------------------------------------------

from game_logic import Tablero, Seguimiento

rival = Tablero()
rival.colocar_barco("Destructor", 0, 0, 2, True)
mis_disparos = Seguimiento()

resultado, barco = rival.recibir_disparo(0, 0)
mis_disparos.registrar(0, 0, resultado)

resultado, barco = rival.recibir_disparo(5, 5)
mis_disparos.registrar(5, 5, resultado)

print(mis_disparos.ya_disparado(0, 0))    # ESPERADO: True   (ya disparamos ahí, y le dimos)
print(mis_disparos.ya_disparado(5, 5))    # ESPERADO: True   (ya disparamos ahí, cayó agua)
print(mis_disparos.ya_disparado(3, 3))    # ESPERADO: False

print()
for f in mis_disparos.celdas:
    print(" ".join(f))
# ESPERADO: una X en la fila 0, columna 0; una O en la fila 5, columna 5; todo lo demás "~"
