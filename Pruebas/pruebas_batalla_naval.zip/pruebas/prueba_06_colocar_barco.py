# LECCIÓN 6: colocar_barco (pone el barco de verdad)
# Cómo ejecutarlo: python prueba_06_colocar_barco.py

# --- Esto permite importar game_logic.py desde la carpeta de arriba ---
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
# ----------------------------------------------------------------------

from game_logic import Tablero

t = Tablero()
print(t.colocar_barco("Destructor", 3, 8, 2, True))    # ESPERADO: True
print(t.colocar_barco("Destructor", 0, 0, 2, True))    # ESPERADO: False (ese nombre ya está colocado)
print(t.colocar_barco("Crucero", 3, 7, 3, False))      # ESPERADO: True  (vertical: (3,7), (4,7), (5,7))

print()
for fila in t.celdas:
    print(" ".join(fila))
# ESPERADO: fila 3 con B en las columnas 8, 9 y 10; y una B en las filas 4 y 5, columna 8

print()
print(t.barcos)
# ESPERADO (el orden dentro de los { } puede cambiar):
# {'Destructor': {(3, 8), (3, 9)}, 'Crucero': {(3, 7), (4, 7), (5, 7)}}
