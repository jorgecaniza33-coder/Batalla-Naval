# LECCIÓN 11: la CPU (rival automático)
# Cómo ejecutarlo: python prueba_11_cpu.py  (córrelo varias veces)

# --- Esto permite importar game_logic.py desde la carpeta de arriba ---
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
# ----------------------------------------------------------------------

from game_logic import Tablero, CPU, nombre_coordenada

print(nombre_coordenada(1, 4))    # ESPERADO: B5

cpu = CPU()
objetivo = Tablero()
objetivo.colocar_barco("Destructor", 4, 4, 2, True)

turnos = 0
while not objetivo.flota_hundida():
    f, c = cpu.elegir()
    resultado, barco = objetivo.recibir_disparo(f, c)
    cpu.informar(f, c, resultado)
    turnos = turnos + 1
    print(turnos, nombre_coordenada(f, c), resultado)

# ESPERADO:
# - La lista termina con "hundido".
# - Después de un "tocado", el siguiente disparo es a una casilla vecina (arriba, abajo, izquierda o derecha).
# - Cada ejecución tarda un número de turnos distinto (la CPU baraja las casillas al azar).
