# LECCIÓN 3: la clase Tablero (el __init__ y las celdas)
# Cómo ejecutarlo: python prueba_03_tablero.py

# --- Esto permite importar game_logic.py desde la carpeta de arriba ---
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
# ----------------------------------------------------------------------

from game_logic import Tablero, BARCO

mi_tablero = Tablero()

print("Tablero vacío:")
for fila in mi_tablero.celdas:
    print(" ".join(fila))
# ESPERADO: 10 filas de 10 "~"

# Pintamos una B "a mano" en la fila 1, columna 4
mi_tablero.celdas[1][4] = BARCO

print()
print("Con una B en celdas[1][4]:")
for fila in mi_tablero.celdas:
    print(" ".join(fila))
# ESPERADO: la B aparece en la 2.ª fila (fila B), 5.ª columna (columna 5) -> casilla B5
# OJO: esto solo cambia el dibujo (celdas). El diccionario barcos sigue vacío:
print()
print(mi_tablero.barcos)    # ESPERADO: {}
