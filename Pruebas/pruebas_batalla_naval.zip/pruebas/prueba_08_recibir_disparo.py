# LECCIÓN 8: recibir_disparo y flota_hundida
# Cómo ejecutarlo: python prueba_08_recibir_disparo.py

# --- Esto permite importar game_logic.py desde la carpeta de arriba ---
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
# ----------------------------------------------------------------------

from game_logic import Tablero

t = Tablero()
t.colocar_barco("Destructor", 0, 0, 2, True)    # ocupa (0,0) y (0,1)

print(t.recibir_disparo(5, 5))     # ESPERADO: ('agua', None)
print(t.recibir_disparo(0, 0))     # ESPERADO: ('tocado', 'Destructor')
print(t.recibir_disparo(0, 0))     # ESPERADO: ('repetido', None)
print(t.flota_hundida())           # ESPERADO: False  (aún le queda la casilla (0,1))
print(t.recibir_disparo(0, 1))     # ESPERADO: ('hundido', 'Destructor')
print(t.recibir_disparo(20, 20))   # ESPERADO: ('invalido', None)
print(t.flota_hundida())           # ESPERADO: True

# Así se "desempaquetan" las dos cosas que devuelve:
t2 = Tablero()
t2.colocar_barco("Destructor", 0, 0, 2, True)
resultado, barco = t2.recibir_disparo(0, 0)
print(resultado, barco)            # ESPERADO: tocado Destructor
