# LECCIÓN 10: mostrar_tableros (tu flota y tus disparos, lado a lado)
# Cómo ejecutarlo: python prueba_10_mostrar_tableros.py

# --- Esto permite importar game_logic.py desde la carpeta de arriba ---
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
# ----------------------------------------------------------------------

from game_logic import Tablero, Seguimiento, mostrar_tableros

# OJO: las variables tienen que existir antes de usarse
rival = Tablero()
rival.colocar_barco("Destructor", 0, 0, 2, True)

tu_flota = Tablero()
tu_flota.colocar_barco("Destructor", 2, 2, 2, False)    # ocupa (2,2) y (3,2)
mis_disparos = Seguimiento()

# Tú le disparas al rival en (0, 0)
resultado, barco = rival.recibir_disparo(0, 0)
mis_disparos.registrar(0, 0, resultado)

# El rival te dispara en (3, 2)
tu_flota.recibir_disparo(3, 2)

mostrar_tableros(tu_flota, mis_disparos)
# ESPERADO:
# - Tablero de la izquierda (TU FLOTA): una B en C3 y una X en D3
# - Tablero de la derecha (TUS DISPAROS): una X en A1
