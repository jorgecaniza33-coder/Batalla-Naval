# Curso: entendiendo `game_logic.py` (Batalla Naval en Python)

Este documento reúne las lecciones que fuimos armando para reconstruir `game_logic.py` paso a paso, con sus retos y sus archivos de prueba.

**Nivel de partida:** bucles `for` y `while`, y apenas listas, tuplas y diccionarios. Todo lo demás se explica cuando aparece.

## Cómo usar este paquete

```
ProyectoJuego/
├── game_logic.py
└── pruebas/
    ├── prueba_01_coordenadas_basicas.py
    ├── ...
    └── prueba_13_flota_aleatoria.py
```

- La carpeta `pruebas/` va **al lado** de `game_logic.py`.
- Cada prueba se ejecuta sola: `python pruebas/prueba_05_puede_colocar.py`
- En cada archivo, los comentarios `# ESPERADO:` dicen qué debería salir. Antes de ejecutar, **predice** la salida y luego compara.
- Las pruebas usan el nombre `TOCADO` para el símbolo de barco golpeado (no aparece directamente en ellas, pero tu `game_logic.py` debería usar ese nombre, igual que `R_TOCADO`).

## Glosario rápido

| Palabra | Qué significa |
|---|---|
| `def` | Crea una **función**: una receta con nombre que se ejecuta cuando la llamas |
| `return` | Devuelve el resultado de la función y sale de ella de inmediato |
| `class` | Un **molde** para crear objetos que guardan datos (cada `Tablero()` es uno distinto) |
| `__init__` | Función especial que se ejecuta sola al crear un objeto y lo deja preparado |
| `self` | "Este objeto en particular": `self.celdas` son las celdas **de este** tablero |
| método | Una función que vive dentro de una clase |
| `_nombre` | Guion bajo al inicio: costumbre para decir "ayudante interna, no la llames desde afuera" |
| `None` | "Nada" / "no válido" |
| tupla `(a, b)` | Un par de valores juntos. Lo que la hace tupla es la **coma** |
| desempaquetar | `resultado, barco = f()` separa los dos valores que devuelve una función |
| `set` (conjunto) | Como una lista, pero sin repetidos y rápido para preguntar "¿ya está esto aquí?" |
| `in` / `not in` | Preguntan si algo está (o no) dentro de una lista, conjunto o diccionario |
| `continue` | Salta al inicio de la siguiente vuelta del bucle |
| `break` | Sale del bucle por completo |
| f-string | Texto con `{ }` donde se insertan valores: `f"{LETRAS[f]}"` |
| `try / except` | "Intenta esto; si da este error, haz lo otro" |
| `if __name__ == "__main__":` | "Ejecuta esto solo si corro **este** archivo directamente" |

---

## Lección 1: constantes y coordenadas básicas

**Idea:** guardar con nombre los valores que se usan en todo el juego, para no escribir `"~"` mil veces ni equivocarte.

```python
TAMANO = 10
LETRAS = "ABCDEFGHIJ"
AGUA = "~"
BARCO = "B"
TOCADO = "X"
FALLO = "O"

def dentro_del_tablero(fila, col):
    return 0 <= fila < TAMANO and 0 <= col < TAMANO
```

- Las filas se nombran con letras (A a J) y las columnas con números (1 a 10).
- Las personas contamos desde 1 y Python desde 0, por eso `B5` es `(1, 4)`.

**Versión simple de `parsear_coordenada`** (la mejoramos en la Lección 2):

```python
def parsear_coordenada(texto):
    letra = texto[0]
    numero = texto[1:]
    fila = LETRAS.index(letra)
    col = int(numero) - 1
    return fila, col
```

**Prueba:** `pruebas/prueba_01_coordenadas_basicas.py`

**Retos:**
1. `parsear_coordenada("J10")` da `(9, 9)`.
2. Un Destructor (largo 2) en `fila=3, col=9` horizontal ocuparía `(3,9)` y `(3,10)`. La columna 10 no existe, así que **no cabe**.

### Mini lección: `def` y `return`

```python
def saludar(nombre):
    print("Hola", nombre)

def doble(numero):
    return numero * 2
```

Escribir el `def` no ejecuta nada, solo guarda la receta. Para usarla hay que **llamarla**: `saludar("Ana")`.

**Reto:** una función `es_par(numero)` que devuelva `True` si el número es par (pista: `numero % 2 == 0`).

---

## Lección 2: que no se rompa con entradas raras

**Idea:** si el jugador escribe `"hola"` o `"Z99"`, la función devuelve `None` en vez de caerse.

```python
def parsear_coordenada(texto):
    texto = texto.strip().upper()

    if len(texto) < 2:
        return None

    letra = texto[0]
    numero = texto[1:]

    if letra not in LETRAS:
        return None
    if not numero.isdigit():
        return None

    fila = LETRAS.index(letra)
    col = int(numero) - 1

    if not dentro_del_tablero(fila, col):
        return None

    return fila, col
```

**Comandos nuevos:** `.strip()` (quita espacios de los lados), `.upper()` (pasa a mayúsculas), `len()` (cuenta caracteres), `not in`, `.isdigit()` (¿son solo números?).

La función revisa todo en orden y sale en cuanto algo falla.

**Prueba:** `pruebas/prueba_02_coordenadas_invalidas.py`

**Reto:** predecir la salida de `["B5", "b5", " J10 ", "Z99", "hola", "A0", "A11", ""]`. Resultado: `(1,4)`, `(1,4)`, `(9,9)`, `None`, `None`, `None`, `None`, `None`.

---

## Lección 3: la clase `Tablero` (parte 1)

**Idea:** una clase es un molde (como uno de galletas). `Tablero()` crea un tablero nuevo con sus propios datos.

```python
class Tablero:
    def __init__(self):
        self.celdas = []
        for f in range(TAMANO):
            fila = []
            for c in range(TAMANO):
                fila.append(AGUA)
            self.celdas.append(fila)
        self.barcos = {}
        self.disparos_recibidos = set()
```

| Atributo | Qué es | Para qué |
|---|---|---|
| `self.celdas` | lista de listas (10x10) | **Dibujar** qué hay en cada casilla: `~`, `B`, `X`, `O` |
| `self.barcos` | diccionario | Guardar qué casillas le quedan **sin tocar** a cada barco |
| `self.disparos_recibidos` | conjunto | Saber dónde ya te dispararon |

`" ".join(fila)` pega los elementos de la lista con un espacio, para imprimir limpio.

**Corrección importante:** `celdas` **no** es el diccionario. Escribir `mi_tablero.celdas[1][4] = BARCO` solo **pinta** una `B`; el diccionario `barcos` ni se entera. Por eso en el juego real se usa `colocar_barco`, que actualiza **las dos cosas**.

**Prueba:** `pruebas/prueba_03_tablero.py`

---

## Lección 4: `_coordenadas`

**Idea:** calcular **qué casillas ocuparía** un barco. No coloca nada ni revisa si está ocupado: es como una regla de medir.

```python
    def _coordenadas(self, fila, col, largo, horizontal):
        coords = []
        for i in range(largo):
            if horizontal:
                coords.append((fila, col + i))
            else:
                coords.append((fila + i, col))
        return coords
```

- `horizontal=True` → el barco va hacia la derecha.
- `horizontal=False` → el barco va hacia abajo.

**Prueba:** `pruebas/prueba_04_coordenadas_del_barco.py`

**Reparto de trabajo (cada función hace una sola cosa):**

| Función | Su trabajo |
|---|---|
| `_coordenadas` | Calcular qué casillas ocuparía el barco |
| `puede_colocar` | Revisar si esas casillas existen y están libres |
| `colocar_barco` | Si se puede, ponerlo de verdad |

---

## Lección 5: `puede_colocar`

```python
    def puede_colocar(self, fila, col, largo, horizontal):
        coords = self._coordenadas(fila, col, largo, horizontal)
        for f, c in coords:
            if not dentro_del_tablero(f, c):
                return False
            if self.celdas[f][c] != AGUA:
                return False
        return True
```

**El orden importa:** primero se revisa que la casilla exista y **después** qué hay en ella. Si miras `self.celdas[3][10]` y no existe, Python da `IndexError`.

**Error común de sangría:** los `def` de la clase deben quedar **alineados** (4 espacios), cada uno debajo del anterior. Si metes un `def` dentro de otro, solo existe mientras ese otro se ejecuta y nadie desde afuera puede usarlo (`AttributeError`).

**Prueba:** `pruebas/prueba_05_puede_colocar.py`

---

## Lección 6: `colocar_barco`

```python
    def colocar_barco(self, nombre, fila, col, largo, horizontal):
        if nombre in self.barcos:
            return False
        if not self.puede_colocar(fila, col, largo, horizontal):
            return False

        coords = self._coordenadas(fila, col, largo, horizontal)
        for f, c in coords:
            self.celdas[f][c] = BARCO
        self.barcos[nombre] = set(coords)
        return True
```

- `nombre in self.barcos` en un diccionario pregunta si esa **clave** existe (no deja colocar el mismo barco dos veces).
- Actualiza **las dos cosas**: `celdas` (para dibujar) y `barcos` (para saber qué barco es cuál).

**Prueba:** `pruebas/prueba_06_colocar_barco.py`

---

## Lección 7: la flota, `flota_completa` y `quitar_barco`

Se declara una sola vez arriba, junto a las constantes:

```python
FLOTA = [
    ("Portaaviones", 5), ("Acorazado", 4),
    ("Crucero", 3), ("Submarino", 3), ("Destructor", 2),
]
```

**Error común:** `("Destructor,2")` con las comillas envolviendo todo es **un solo texto**, no una tupla. Lo correcto es `("Destructor", 2)`.

```python
    def flota_completa(self):
        return len(self.barcos) == len(FLOTA)

    def quitar_barco(self, nombre):
        coords = self.barcos.pop(nombre, None)
        if coords is None:
            return False
        for f, c in coords:
            self.celdas[f][c] = AGUA
        return True
```

- `.pop(nombre, None)` saca la clave del diccionario y devuelve su valor; si no existe, devuelve `None` en vez de dar error.
- `is None` es la forma de preguntar si algo es `None`.

**Prueba:** `pruebas/prueba_07_flota_y_quitar.py`

**Retos:** las filas 0 a 4 quedan con 5, 4, 3, 3 y 2 letras `B`; el primer `flota_completa()` da `True` y el segundo `False`; `quitar_barco("Lancha")` devuelve `False` sin romperse.

---

## Lección 8: `recibir_disparo` y `flota_hundida`

Las respuestas posibles, como constantes:

```python
R_AGUA = "agua"
R_TOCADO = "tocado"
R_HUNDIDO = "hundido"
R_REPETIDO = "repetido"
R_INVALIDO = "invalido"
```

```python
    def recibir_disparo(self, fila, col):
        if not dentro_del_tablero(fila, col):
            return R_INVALIDO, None
        if (fila, col) in self.disparos_recibidos:
            return R_REPETIDO, None

        self.disparos_recibidos.add((fila, col))

        if self.celdas[fila][col] == BARCO:
            self.celdas[fila][col] = TOCADO
            for nombre, restantes in self.barcos.items():
                if (fila, col) in restantes:
                    restantes.discard((fila, col))
                    if len(restantes) == 0:
                        return R_HUNDIDO, nombre
                    return R_TOCADO, nombre
        self.celdas[fila][col] = FALLO
        return R_AGUA, None

    def flota_hundida(self):
        for restantes in self.barcos.values():
            if len(restantes) > 0:
                return False
        return len(self.barcos) > 0
```

- Devuelve **dos cosas**: `(resultado, nombre_del_barco)`. Se separan con `resultado, barco = t.recibir_disparo(f, c)` (desempaquetar).
- `.items()` recorre cada pareja nombre/conjunto del diccionario; `.values()` solo los valores.
- `.add()` agrega a un conjunto; `.discard()` quita un elemento.
- Volver a preguntarle al jugador cuando el disparo es inválido **no** lo hace este archivo: lo hace el código del juego, usando estas respuestas.

**Prueba:** `pruebas/prueba_08_recibir_disparo.py` (son 7 `print` más un ejemplo de desempaquetado)

**Para los extras del proyecto:** sonidos según `agua`/`tocado`/`hundido`, y fueguito en las casillas que valgan `TOCADO`.

---

## Lección 9: `Seguimiento`

**Idea:** del rival no ves sus barcos, solo el resultado de **tus disparos**. Por eso tú tienes un `Tablero` (tus barcos) y un `Seguimiento` (tus tiros contra el rival).

```python
class Seguimiento:
    def __init__(self):
        self.celdas = []
        for f in range(TAMANO):
            fila = []
            for c in range(TAMANO):
                fila.append(AGUA)
            self.celdas.append(fila)

    def ya_disparado(self, fila, col):
        return self.celdas[fila][col] != AGUA

    def registrar(self, fila, col, resultado):
        if resultado == R_AGUA:
            self.celdas[fila][col] = FALLO
        else:
            self.celdas[fila][col] = TOCADO
```

`ya_disparado` dice `True` si en esa casilla **ya disparaste** (sea agua o barco), no si "acertaste".

**Prueba:** `pruebas/prueba_09_seguimiento.py`

---

## Lección 10: `mostrar_tableros`

Dibuja tu flota y tus disparos lado a lado. Va **sin sangría**, fuera de las clases.

```python
def mostrar_tableros(propio, seguimiento):
    cabecera = "   "
    for i in range(1, TAMANO + 1):
        cabecera = cabecera + f"{i:>2} "

    print()
    print("TU FLOTA".ljust(35) + "TUS DISPAROS")
    print(cabecera + "  " + cabecera)

    for f in range(TAMANO):
        izq = ""
        der = ""
        for c in range(TAMANO):
            izq = izq + f"{propio.celdas[f][c]:>2} "
            der = der + f"{seguimiento.celdas[f][c]:>2} "
        lado_izq = f" {LETRAS[f]} " + izq
        lado_der = f" {LETRAS[f]} " + der
        print(lado_izq + "  " + lado_der)
    print()
```

- `:>2` alinea a la derecha usando 2 espacios (para que `1` y `10` queden en columna).
- `.ljust(35)` rellena con espacios a la derecha hasta 35 caracteres.
- `texto = texto + algo` va pegando pedazos.

**Error común:** usar una variable antes de crearla (`rival` no definido). Un nombre tiene que existir antes de usarlo.

**Prueba:** `pruebas/prueba_10_mostrar_tableros.py`

---

## Lección 11: la CPU

Necesita `import random` arriba del archivo y esta función auxiliar:

```python
def nombre_coordenada(fila, col):
    return LETRAS[fila] + str(col + 1)     # (1, 4) -> "B5"
```

```python
class CPU:
    def __init__(self):
        self.disponibles = []
        for f in range(TAMANO):
            for c in range(TAMANO):
                self.disponibles.append((f, c))
        random.shuffle(self.disponibles)
        self.objetivos = []

    def elegir(self):
        while len(self.objetivos) > 0:
            f, c = self.objetivos.pop()
            if (f, c) in self.disponibles:
                self.disponibles.remove((f, c))
                return f, c
        return self.disponibles.pop()

    def informar(self, fila, col, resultado):
        if resultado == R_TOCADO:
            for df, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                vecino = (fila + df, col + dc)
                if vecino in self.disponibles:
                    self.objetivos.append(vecino)
```

- `random.shuffle` **baraja** la lista, como un mazo de cartas.
- Si `objetivos` **tiene** casillas (vecinas de un acierto), saca una de ahí. Si está **vacía**, saca una de `disponibles`, que ya está barajada (al azar).
- `informar` solo hace algo con `tocado`: si ya `hundió` el barco, no tiene sentido seguir probando alrededor.
- Cada ejecución tarda un número distinto de turnos porque el orden cambia.

**Prueba:** `pruebas/prueba_11_cpu.py` (córrela varias veces)

---

## Lección 12: `Conexion` (la parte de red)

**Ideas básicas:**
- **Socket:** una "línea telefónica" entre dos programas.
- **JSON:** convierte un diccionario en texto para viajar por la red, y de vuelta.
- **Un mensaje por línea:** cada mensaje termina con `"\n"` para que el que escucha sepa dónde acaba uno y empieza el siguiente.

Imports arriba del archivo: `import json` y `import socket`.

```python
class Conexion:
    def __init__(self, sock):
        self.sock = sock
        self._lector = sock.makefile("r", encoding="utf-8")

    def enviar(self, mensaje):
        datos = json.dumps(mensaje) + "\n"
        self.sock.sendall(datos.encode("utf-8"))

    def recibir(self):
        try:
            linea = self._lector.readline()
        except (OSError, ValueError):
            return None
        if not linea:
            return None
        return json.loads(linea)

    def cerrar(self):
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            self._lector.close()
            self.sock.close()
        except OSError:
            pass
```

- `.encode("utf-8")` convierte el texto en **bytes**, que es lo único que viaja por la red.
- `recibir()` **espera** hasta que llegue una línea. Si llega vacía, el otro se desconectó y devuelve `None`.
- `socket.socketpair()` crea dos sockets ya conectados entre sí, ideal para probar sin red.

**Prueba:** `pruebas/prueba_12_conexion.py`

**Retos:** salidas esperadas: el disparo, el resultado y `None` (tras cerrar). Si el mensaje no lleva `"tipo"`, llega igual: JSON no obliga a tener esa clave, es solo una costumbre para que el receptor sepa qué hacer con el mensaje.

---

## Lección 13: `colocar_flota_aleatoria` y el juego local

Se agrega dentro de `class Tablero`:

```python
    def colocar_flota_aleatoria(self):
        self.__init__()
        for nombre, largo in FLOTA:
            while True:
                fila = random.randrange(TAMANO)
                col = random.randrange(TAMANO)
                horizontal = random.choice([True, False])
                if self.colocar_barco(nombre, fila, col, largo, horizontal):
                    break
```

- `self.__init__()` vuelve a ejecutar el `__init__` y deja el tablero limpio.
- El `while True` prueba posiciones al azar hasta que `colocar_barco` devuelve `True`; ahí hace `break`.

**Prueba:** `pruebas/prueba_13_flota_aleatoria.py` (siempre deben salir 17 casillas de barco: 5+4+3+3+2)

**El juego tú vs CPU** (Lección 13; en la Lección 14 se mueve a `juego.py`):

```python
def jugar_local():
    tu_flota = Tablero()
    tu_flota.colocar_flota_aleatoria()
    rival = Tablero()
    rival.colocar_flota_aleatoria()
    mis_disparos = Seguimiento()
    cpu = CPU()

    while True:
        mostrar_tableros(tu_flota, mis_disparos)

        texto = input("Tu disparo (ej. B5): ")
        coord = parsear_coordenada(texto)
        if coord is None:
            print("Coordenada inválida, intenta otra vez")
            continue
        fila, col = coord
        if mis_disparos.ya_disparado(fila, col):
            print("Ya disparaste ahí, elige otra casilla")
            continue

        resultado, barco = rival.recibir_disparo(fila, col)
        mis_disparos.registrar(fila, col, resultado)
        print("Resultado:", resultado)
        if rival.flota_hundida():
            print("¡Ganaste!")
            break

        f, c = cpu.elegir()
        resultado, barco = tu_flota.recibir_disparo(f, c)
        cpu.informar(f, c, resultado)
        print("La CPU disparó a", nombre_coordenada(f, c), "->", resultado)
        if tu_flota.flota_hundida():
            print("Perdiste")
            break
```

- `input("texto")` muestra un mensaje y espera a que el jugador escriba.
- `continue` repite el turno del jugador sin que juegue la CPU; `break` sale del bucle (fin de la partida).

**Retos:** escribir `hola` no pierde el turno porque `continue` vuelve al inicio antes de llegar al turno de la CPU. Mejora pendiente: un contador de turnos para decir `¡Ganaste en X turnos!`.

---

## Lección 14 (pendiente): separar el juego en `juego.py`

`game_logic.py` debe tener **solo las reglas**; el juego con `input` y `print` vive en `juego.py`:

```python
from game_logic import (
    Tablero, Seguimiento, CPU,
    parsear_coordenada, nombre_coordenada, mostrar_tableros,
)

def jugar_local():
    ...   # el mismo código de arriba

if __name__ == "__main__":
    jugar_local()
```

Pasos: 1) borrar `jugar_local()` y pruebas sueltas de `game_logic.py`; 2) cambiar `TOQUE` por `TOCADO` si aún no se hizo; 3) crear `juego.py` en la misma carpeta; 4) **reto:** un mini menú con `while` (1. Jugar contra la CPU, 2. Jugar en red (próximamente), 3. Salir).

---

## Errores comunes que aparecieron en el camino

1. **Sangría:** metiste un `def` dentro de otro. Los métodos de una clase deben ir alineados.
2. **Comillas en una tupla:** `("Destructor,2")` es un texto, no un par.
3. **Variable no definida:** usar `rival` sin haberla creado.
4. **`jugar_local()` suelto al final de `game_logic.py`:** se ejecuta al importarlo. Usar `if __name__ == "__main__":` o moverlo a `juego.py`.
5. **Nombres distintos entre archivos** (`TOQUE` vs `TOCADO`): decidir uno y usarlo igual en todos los archivos del equipo.

## Contrato de nombres de `game_logic.py` (para el equipo)

| Qué | Nombres |
|---|---|
| Constantes | `TAMANO`, `LETRAS`, `AGUA`, `BARCO`, `TOCADO`, `FALLO`, `FLOTA` |
| Resultados | `R_AGUA`, `R_TOCADO`, `R_HUNDIDO`, `R_REPETIDO`, `R_INVALIDO` |
| Funciones | `dentro_del_tablero`, `parsear_coordenada`, `nombre_coordenada`, `mostrar_tableros` |
| Clases | `Tablero`, `Seguimiento`, `CPU`, `Conexion` |
| `Tablero` | `colocar_barco`, `quitar_barco`, `puede_colocar`, `flota_completa`, `colocar_flota_aleatoria`, `recibir_disparo`, `flota_hundida` |
| `Seguimiento` | `ya_disparado`, `registrar` |
| `CPU` | `elegir`, `informar` |
| `Conexion` | `enviar`, `recibir`, `cerrar` |

## Nota para el README (créditos)

Si usas este material, déjalo declarado en el README: se usó Claude (Anthropic) para entender y explicar el código de `game_logic.py`.
